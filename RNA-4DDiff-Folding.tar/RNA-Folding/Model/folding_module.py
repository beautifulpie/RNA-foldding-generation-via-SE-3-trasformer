"""
Code adapted from
https://github.com/microsoft/protein-frame-flow/blob/main/models/flow_module.py
"""

import torch
import time
import os
import random
import wandb
import numpy as np
import pandas as pd
import logging
from pytorch_lightning import LightningModule
import sys
sys.path.append("/workspace/4D-Diff-RNA_test_1/")
from Model.analysis import metrics
from Model.analysis import utils as au
from Model import diff_model
from Model import utils as mu
from data.interpolant import Interpolant 
from data import utils as du
from data import all_atom as rna_all_atom
from data import so3_utils
from data import nucleotide_constants
from Model.analysis import utils as au
from pytorch_lightning.loggers.wandb import WandbLogger
import subprocess

class FlowModule(LightningModule):
    def __init__(self, cfg, folding_cfg=None):
        super().__init__()
        self._print_logger = logging.getLogger(__name__)
        self._exp_cfg = cfg.experiment
        self._model_cfg = cfg.model
        self._interpolant_cfg = cfg.interpolant

        # Set-up vector field prediction model
        self.model = diff_model.FlowModel(cfg.model)

        # Set-up interpolant
        self.interpolant = Interpolant(cfg.interpolant)

        self._sample_write_dir = self._exp_cfg.checkpointer.dirpath
        os.makedirs(self._sample_write_dir, exist_ok=True)

        self.validation_epoch_metrics = []
        self.validation_epoch_samples = []
        self.save_hyperparameters()
        self.batch_size = cfg.data_cfg.batch_size

        self.debug_dir = "debug_outputs"
        os.makedirs(self.debug_dir, exist_ok=True)

        self.val_bb = None
        self.val_org_len = None
        self.val_trans = None
        self.val_rotmats = None
        self.val_tors = None
        self.val_aatype = None
        self.validation_step_outputs = []

        self.min_loss = float('inf')
        
    def on_train_start(self):
        self._epoch_start_time = time.time()
        
    def on_train_epoch_end(self):

        # if self.current_epoch == 20:
        #     torch.save(self.first_pred, os.path.join(self.debug_dir, "first_pred_epoch0.pt"))
        #     torch.save(self.first_gt, os.path.join(self.debug_dir, "first_gt_epoch0.pt"))
        #     torch.save(self.last_pred, os.path.join(self.debug_dir, "last_pred_epoch0.pt"))
        #     torch.save(self.last_gt, os.path.join(self.debug_dir, "last_gt_epoch0.pt"))
        #     torch.save(self.first_aatype, os.path.join(self.debug_dir, "first_aatype_epoch0.pt"))
        #     torch.save(self.first_gt_tors, os.path.join(self.debug_dir, "first_gt_tors_epoch0.pt"))
        #     torch.save(self.first_pred_tors, os.path.join(self.debug_dir, "first_pred_tors_epoch0.pt"))
        #     torch.save(self.last_aatype, os.path.join(self.debug_dir, "last_aatype_epoch0.pt"))
        #     torch.save(self.last_gt_tors, os.path.join(self.debug_dir, "last_gt_tors_epoch0.pt"))
        #     torch.save(self.last_pred_tors, os.path.join(self.debug_dir, "last_pred_tors_epoch0.pt"))
        #     torch.save(self.last_pred_rotmats, os.path.join(self.debug_dir, "last_pred_rotmats_epoch0.pt"))
        #     torch.save(self.last_gt_rotmats, os.path.join(self.debug_dir, "last_gt_rotmats_epoch0.pt"))
        #     torch.save(self.first_pred_rotmats, os.path.join(self.debug_dir, "first_pred_rotmats_epoch0.pt"))
        #     torch.save(self.first_gt_rotmats, os.path.join(self.debug_dir, "first_gt_rotmats_epoch0.pt"))
        #     torch.save(self.last_pred_trans, os.path.join(self.debug_dir, "last_pred_trans_epoch0.pt"))
        #     torch.save(self.last_gt_trans, os.path.join(self.debug_dir, "last_gt_trans_epoch0.pt"))
        #     torch.save(self.first_pred_trans, os.path.join(self.debug_dir, "first_pred_trans_epoch0.pt"))
        #     torch.save(self.first_gt_trans, os.path.join(self.debug_dir, "first_gt_trans_epoch0.pt"))


        #     print(f"✅ Debug outputs saved in {self.debug_dir} after 20 epoch")

        
        # if self.current_epoch == 1:
        #     torch.save(self.gt_bb_atoms_list, os.path.join(self.debug_dir, "gt_bb_atoms_epoch1.pt"))
        #     torch.save(self.pred_bb_atoms_list, os.path.join(self.debug_dir, "pred_bb_atoms_epoch1.pt"))
        #     print(f"✅ Debug outputs saved in {self.debug_dir}")
        #     self.gt_bb_atoms_list.clear()
        #     self.pred_bb_atoms_list.clear()

        self.min_loss = float('inf')

        epoch_time = (time.time() - self._epoch_start_time) / 60.0
        self.log(
            'train/epoch_time_minutes',
            epoch_time,
            on_step=False,
            on_epoch=True,
            prog_bar=False
        )
        self._epoch_start_time = time.time()

    def model_step(self, noisy_batch):
        """
        Params:
            noisy_batch (dict) : dictionary of tensors corresponding to corrupted Frame objects

        Remarks:
            Computes the different core and auxiliary losses between ground truth and predicted backbones

        Returns:
            Dictionary of core and auxiliary losses
        """
        
        training_cfg = self._exp_cfg.training
        loss_mask = noisy_batch['res_mask']
        is_na_residue_mask = noisy_batch["is_na_residue_mask"]
        
        if training_cfg.min_plddt_mask is not None:
            plddt_mask = noisy_batch['res_plddt'] > training_cfg.min_plddt_mask
            loss_mask *= plddt_mask
        
        num_batch, num_res = loss_mask.shape  # batch, 300

        torsions_start_index = 0
        torsions_end_index = 8
        num_torsions = torsions_end_index - torsions_start_index

        aatype = noisy_batch['aatype']

        org_len = noisy_batch['org_len']
        org_len = torch.tensor(org_len)
        num_traj = num_batch // self.batch_size
        org_len_repeated = org_len.repeat_interleave(num_traj)

        if training_cfg.num_non_frame_atoms == 0:
            bb_filtered_atom_idx = [2, 3, 6] # [C3', C4', O4']
        elif training_cfg.num_non_frame_atoms == 3:
            bb_filtered_atom_idx = [2, 3, 6] + [0, 7, 9] # [C3', C4', O4'] + [C1', O3', P]
        elif training_cfg.num_non_frame_atoms == 7:
            bb_filtered_atom_idx = [2, 3, 6] + [0, 4, 7, 9, 10, 11, 12] # [C3', C4', O4'] + [C1', C5', O3', P, OP1, OP2, N1]
        else:
            # NOTE: default is the original frame
            bb_filtered_atom_idx = [2, 3, 6] # [C3', C4', O4']
        
        n_merged_atoms = len(bb_filtered_atom_idx)

        # Ground truth labels
        gt_trans_1 = noisy_batch['trans_1']
        gt_rotmats_1 = noisy_batch['rotmats_1']
        
        gt_torsions_1 = noisy_batch['torsion_angles_sin_cos'][:, :, torsions_start_index:torsions_end_index, :].reshape(num_batch, num_res, num_torsions * 2)
        rotmats_t = noisy_batch['rotmats_t']
        trans_t = noisy_batch['trans_t']
        gt_rot_vf = so3_utils.calc_rot_vf(rotmats_t, gt_rotmats_1.type(torch.float32))
        # print(f"In batch : { noisy_batch['torsion_angles_sin_cos'].shape }")
        # print(f"gt_trans_1 : {gt_trans_1.shape}")
        # print(f"gt_rotmats_1 : {gt_rotmats_1.shape}")
        # print(f"is_na_residue_mask : {is_na_residue_mask.shape}")
        # print(f"gt_torsions_1 : {gt_torsions_1.shape}")
        
        gt_bb_atoms = rna_all_atom.to_atom37_rna(
                            gt_trans_1, gt_rotmats_1, 
                            torch.ones_like(is_na_residue_mask),
                            torsions=gt_torsions_1
                        )
        gt_bb_atoms = gt_bb_atoms[:, :, bb_filtered_atom_idx]

        # Timestep used for normalization.
        t = noisy_batch['t']
        norm_scale = 1 - torch.min(t[..., None], torch.tensor(training_cfg.t_normalize_clip))
        
        # Model output predictions.
        model_output = self.model(noisy_batch)
        pred_trans_1 = model_output['pred_trans']
        pred_rotmats_1 = model_output['pred_rotmats']
        pred_torsions_1 = model_output['pred_torsions'].reshape(num_batch, num_res, num_torsions * 2)
        pred_rots_vf = so3_utils.calc_rot_vf(rotmats_t, pred_rotmats_1)

        pred_trans_1 = du.apply_padding(pred_trans_1, org_len_repeated)
        pred_rotmats_1 = du.apply_padding(pred_rotmats_1, org_len_repeated)
        pred_torsions_1 = du.apply_padding(pred_torsions_1, org_len_repeated)

        # Backbone atom loss
        pred_bb_atoms = rna_all_atom.to_atom37_rna(
                            pred_trans_1, pred_rotmats_1, 
                            torch.ones_like(is_na_residue_mask),
                            torsions=pred_torsions_1
                        )
        pred_bb_atoms = pred_bb_atoms[:, :, bb_filtered_atom_idx]
        
        gt_bb_atoms *= training_cfg.bb_atom_scale / norm_scale[..., None]
        pred_bb_atoms *= training_cfg.bb_atom_scale / norm_scale[..., None]
        loss_denom = torch.sum(loss_mask, dim=-1) * n_merged_atoms
        bb_atom_loss = torch.sum((gt_bb_atoms - pred_bb_atoms) ** 2 * loss_mask[..., None, None], dim=(-1, -2, -3)) / loss_denom

        # if not hasattr(self, "saved_debug") or not self.saved_debug:
        #     os.makedirs("debug_outputs", exist_ok=True)

        #     save_path = "debug_outputs/bb_atoms_step0.pt"
        #     torch.save({
        #         "gt_bb_atoms": gt_bb_atoms.cpu(),
        #         "pred_bb_atoms": pred_bb_atoms.cpu()
        #     }, save_path)

        #     print(f"Backbone atom tensors saved at: {save_path}")
        # self.saved_debug = True  # 이후 실행에서는 저장하지 않음

        # Translation VF loss
        trans_error = (gt_trans_1 - pred_trans_1) / norm_scale * training_cfg.trans_scale
        loss_denom = torch.sum(loss_mask, dim=-1) * 3  # 3 frame atoms
        lambda_trans = ((1 - torch.exp(-t)) / torch.exp(-t / 2)).squeeze(-1)
        trans_loss = lambda_trans * torch.sum(
            trans_error ** 2 * loss_mask[..., None],
            dim=(-1, -2)
        ) / loss_denom

        # Rotation VF loss
        rots_vf_error = (gt_rot_vf - pred_rots_vf) / norm_scale
        loss_denom = torch.sum(loss_mask, dim=-1) * 3  # 3 frame atoms
        lambda_rots = (1 / torch.norm(gt_rot_vf, dim=(1, 2)))
        rots_vf_loss = lambda_rots * torch.sum(
            rots_vf_error ** 2 * loss_mask[..., None],
            dim=(-1, -2)
        ) / loss_denom

        # Pairwise distance loss
        gt_flat_atoms = gt_bb_atoms.reshape([num_batch, num_res * n_merged_atoms, 3]) 
        gt_pair_dists = torch.linalg.norm(gt_flat_atoms[:, :, None, :] - gt_flat_atoms[:, None, :, :], dim=-1)
        pred_flat_atoms = pred_bb_atoms.reshape([num_batch, num_res * n_merged_atoms, 3]) 
        pred_pair_dists = torch.linalg.norm(pred_flat_atoms[:, :, None, :] - pred_flat_atoms[:, None, :, :], dim=-1)

        flat_loss_mask = torch.tile(loss_mask[:, :, None], (1, 1, n_merged_atoms))
        flat_loss_mask = flat_loss_mask.reshape([num_batch, num_res * n_merged_atoms])
        flat_res_mask = torch.tile(loss_mask[:, :, None], (1, 1, n_merged_atoms))
        flat_res_mask = flat_res_mask.reshape([num_batch, num_res * n_merged_atoms]) 

        gt_pair_dists = gt_pair_dists * flat_loss_mask[..., None]
        pred_pair_dists = pred_pair_dists * flat_loss_mask[..., None]
        pair_dist_mask = flat_loss_mask[..., None] * flat_res_mask[:, None, :]

        # dist_mat_loss = torch.sum((gt_pair_dists - pred_pair_dists)**2 * pair_dist_mask, dim=(1, 2))
        # dist_mat_loss /= (torch.sum(pair_dist_mask, dim=(1, 2)) - num_res)

        dist_mask = (pred_pair_dists < training_cfg.dist_mat)
        dist_mat_loss = torch.sum((gt_pair_dists - pred_pair_dists)**2 * pair_dist_mask * dist_mask, dim=(1, 2))
        valid_pair_count = torch.sum(pair_dist_mask * dist_mask, dim=(1, 2)).clamp(min=1)
        num_valid_res = torch.sum(loss_mask, dim=-1)
        dist_mat_loss /= (valid_pair_count - num_valid_res)
        # print("valid_pair_count:", valid_pair_count)
        # print("num_res:", num_res)
        # print(dist_mat_loss)

        # Torsion angles loss
        pred_torsions_1 = pred_torsions_1.reshape(num_batch, num_res, num_torsions, 2)
        gt_torsions_1 = gt_torsions_1.reshape(num_batch, num_res, num_torsions, 2)
        loss_denom = torch.sum(loss_mask, dim=-1) * 8  # 8 torsion angles
        tors_loss = training_cfg.tors_loss_scale * torch.sum(
            torch.linalg.norm(pred_torsions_1 - gt_torsions_1, dim=-1) ** 2 * loss_mask[..., None], dim=(-1, -2)
        ) / loss_denom

        assert bb_atom_loss.shape[0] == dist_mat_loss.shape[0] == tors_loss.shape[0], f"Loss tensors shape mismatch: {bb_atom_loss.shape} vs {dist_mat_loss.shape} vs {tors_loss.shape}"
        
        se3_vf_loss = trans_loss + rots_vf_loss  #dsm loss
        auxiliary_loss = (bb_atom_loss + dist_mat_loss) * (t[:, 0] < training_cfg.aux_loss_t_pass)
        auxiliary_loss *= self._exp_cfg.training.aux_loss_weight

        if torch.isnan(auxiliary_loss).any():
            print(bb_atom_loss)
            print(dist_mat_loss)
            print ("NaN loss in aux_loss")
            auxiliary_loss = torch.zeros_like(auxiliary_loss).to(se3_vf_loss.device)
        
        if torch.isnan(se3_vf_loss).any():
            # raise ValueError('NaN loss encountered')
            print ("NaN loss in se3_vf_loss")
            se3_vf_loss = torch.zeros_like(se3_vf_loss).to(se3_vf_loss.device)
        
        auxiliary_loss = auxiliary_loss * 0.25

        total_loss = se3_vf_loss + auxiliary_loss + tors_loss
        # total_loss = se3_vf_loss

        total_loss_sum = torch.sum(total_loss)

        # if self.current_epoch == 0 and self.global_step == 0:
        #     self.first_pred = pred_bb_atoms
        #     self.first_gt = gt_bb_atoms
        #     self.first_aatype = aatype
        #     self.first_gt_tors = gt_torsions_1
        #     self.first_pred_tors = pred_torsions_1
        #     self.first_pred_rotmats = pred_rotmats_1
        #     self.first_pred_trans = pred_trans_1
        #     self.first_gt_rotmats = gt_rotmats_1
        #     self.first_gt_trans = gt_trans_1
        # if self.current_epoch == 20:
        #     if (total_loss_sum < loss_min):
        #         loss_min = total_loss_sum
        #         self.last_pred = pred_bb_atoms
        #         self.last_gt = gt_bb_atoms
        #         self.last_aatype = aatype
        #         self.last_gt_tors = gt_torsions_1
        #         self.last_pred_tors = pred_torsions_1
        #         self.last_pred_rotmats = pred_rotmats_1
        #         self.last_pred_trans = pred_trans_1
        #         self.last_gt_rotmats = gt_rotmats_1
        #         self.last_gt_trans = gt_trans_1

        # if torch.max(trans_loss).item() > 100:
        #     self.gt_bb_atoms_list.append(gt_bb_atoms.cpu().tolist())
        #     self.pred_bb_atoms_list.append(pred_bb_atoms.cpu().tolist())
        # print(f"Tot_loss : {total_loss_sum},  min_loss : {self.min_loss}")

        # if (total_loss_sum < self.min_loss):
        #     self.min_loss = total_loss_sum
        #     self.val_bb = pred_bb_atoms
        #     self.val_org_len = org_len
        #     self.val_trans = pred_trans_1
        #     self.val_rotmats = pred_rotmats_1
        #     self.val_tors = pred_torsions_1
        #     self.val_aatype = aatype

        return {
            "bb_atom_loss": bb_atom_loss,
            "trans_loss": trans_loss,
            "dist_mat_loss": dist_mat_loss,
            "auxiliary_loss": auxiliary_loss,
            "rots_vf_loss": rots_vf_loss,
            "se3_vf_loss": se3_vf_loss,
            "torsion_loss": tors_loss,
            "total_loss": total_loss
        }


    def validation_step(self, batch, batch_idx):
        with torch.no_grad():
            # 1. 배치의 device 설정 및 노이즈 추가된 배치 생성
            self.interpolant.set_device(batch['res_mask'].device)
            noisy_batch = self.interpolant.corrupt_batch(batch)
            
            # 2. (옵션) self-conditioning 적용 (설정되어 있다면)
            if self._interpolant_cfg.self_condition:
                model_sc = self.model(noisy_batch)
                noisy_batch['trans_sc'] = model_sc['pred_trans']
                
            # 3. 모델 손실 계산
            batch_losses = self.model_step(noisy_batch)
            num_batch = batch_losses['bb_atom_loss'].shape[0]
            
            # 4. 각 손실 항목에 대해 평균값 계산 및 로깅
            total_losses = { k: torch.mean(v) for k, v in batch_losses.items() }
            for k, v in total_losses.items():
                self._log_scalar(f"valid/{k}", v, prog_bar=False, batch_size=num_batch)
            
            # 추가 메트릭 로깅
            t = torch.squeeze(noisy_batch['t'])
            self._log_scalar("valid/t", np.mean(du.to_numpy(t)), prog_bar=False, batch_size=num_batch)
            self._log_scalar("valid/length", batch['res_mask'].shape[1], prog_bar=False, batch_size=num_batch)
            self._log_scalar("valid/batch_size", num_batch, prog_bar=False)
            
            # 5. 최종 validation 손실 계산 및 로깅
            valid_loss = total_losses[self._exp_cfg.training.loss] + total_losses['total_loss']
            self._log_scalar("valid/loss", valid_loss, batch_size=num_batch)
        
        if not hasattr(self, "validation_step_outputs"):
            self.validation_step_outputs = []
        self.validation_step_outputs.append({"val_loss": valid_loss})

        return {"val_loss": valid_loss}


    def validation_step_inst(self, batch, batch_idx):
        """
        Generates samples and computes (average) local structural metrics 
        such as C4'-C4' distances, steric clashes, gyration radius.
        """
        print(f"{batch} ")

        with torch.no_grad():
            self.interpolant.set_device(batch['res_mask'].device) 
            noisy_batch = self.interpolant.corrupt_batch(batch) 
            loss_mask = noisy_batch['res_mask']
            is_na_residue_mask = noisy_batch["is_na_residue_mask"]

            training_cfg = self._exp_cfg.training
            if training_cfg.min_plddt_mask is not None:
                plddt_mask = noisy_batch['res_plddt'] > training_cfg.min_plddt_mask
                loss_mask *= plddt_mask

                device = f'cuda:{torch.cuda.current_device()}'

        org_len = noisy_batch['org_len']
        org_len = torch.tensor(org_len)
        
        with torch.no_grad():
            model_sc = self.model(noisy_batch)
            noisy_batch['trans_sc'] = model_sc['pred_trans']

        batch_losses = self.model_step(noisy_batch)
        num_batch = batch_losses['bb_atom_loss'].shape[0]

        res_mask = batch['res_mask']
        num_batch = res_mask.shape[0]

        pred_trans = model_sc['pred_trans']
        pred_rotmats = model_sc['pred_rotmats']
        pred_torsions = model_sc['pred_torsions']
        
        # is_na_residue_mask = torch.ones(num_batch, self.val_org_len, device = self.val_bb.device).bool()
        # padding_tensor = torch.zeros(num_batch, self.val_trans.size(1) - self.val_org_len, device = self.val_bb.device).bool()

        # is_na_residue_mask = torch.cat([is_na_residue_mask, padding_tensor], dim = 1)

        trans = pred_trans[:, :org_len, :]
        rotmats = pred_rotmats[:, :org_len, :]
        tors = pred_torsions[:, :org_len, :]

        traj = [(trans, rotmats)]

        val_rna = rna_all_atom.transrot_to_atom37_rna(traj, is_na_residue_mask, tors)

        for i in range(num_batch):
            final_pos = val_rna[0][i]
            saved_rna_path = au.write_complex_to_pdbs(
                final_pos,
                os.path.join(self._sample_write_dir, f'sample_{i}_idx_{batch_idx}_len_{self.val_org_len}.pdb'),
                is_na_residue_mask=is_na_residue_mask.detach().cpu().numpy()[i],
                no_indexing=True
            )

            if isinstance(self.logger, WandbLogger):
                self.validation_epoch_samples.append(
                    [saved_rna_path, self.global_step, wandb.Molecule(saved_rna_path)]
                )
            c4_idx = nucleotide_constants.atom_order["C4\'"]
            rna_c4_c4_matrics = metrics.calc_rna_c4_c4_metrics(final_pos[:, c4_idx])
            batch_metrics.append(rna_c4_c4_matrics)

        batch_metrics = pd.DataFrame(batch_metrics)
        self.validation_epoch_metrics.append(batch_metrics)
    
    def inst_validation_step(self, batch):
        with torch.no_grad():
            self.interpolant.set_device(batch['res_mask'].device) 
            noisy_batch = self.interpolant.corrupt_batch(batch) 
            loss_mask = noisy_batch['res_mask']
            is_na_residue_mask = noisy_batch["is_na_residue_mask"]

            training_cfg = self._exp_cfg.training
            if training_cfg.min_plddt_mask is not None:
                plddt_mask = noisy_batch['res_plddt'] > training_cfg.min_plddt_mask
                loss_mask *= plddt_mask

                device = f'cuda:{torch.cuda.current_device()}'
                
        interpolant = Interpolant(self._infer_cfg.interpolant) 
        interpolant.set_device(device)

        sample_length = batch['num_res'].item()
        diffuse_mask = torch.ones(1, sample_length).long().unsqueeze(0)
        sample_id = batch['sample_id'].item()
        sample_dir = os.path.join(self._output_dir, f'length_{sample_length}')
        os.makedirs(sample_dir, exist_ok=True)

        atom37_traj, _, _ = interpolant.sample(1, sample_length, self.model)
        bb_traj = du.to_numpy(torch.concat(atom37_traj, dim=0)) # convert from torch to numpy for easier processing

        sample = bb_traj[-1] # store last state (at the final ODESolve timestep) as completed sample
        
        # store RNA backbone sample as PDB file at `saved_rna_path` specified above
        saved_rna_path = au.write_complex_to_pdbs(
                sample,
                os.path.join(sample_dir, f'sample_{sample_id}'),
                is_na_residue_mask=diffuse_mask.detach().cpu(),
            )
        
        saved_rna_traj_path = au.write_complex_to_pdbs(
                bb_traj,
                os.path.join(sample_dir, f'sample_{sample_id}'),
                is_na_residue_mask=diffuse_mask.detach().cpu(),
            )

    def evaluation_step(self, batch):
        col_batch = batch


    def on_validation_epoch_end(self):
        # validation_step에서 저장한 결과가 있는지 확인
        if hasattr(self, "validation_step_outputs") and self.validation_step_outputs:
            # 각 validation_step에서 계산한 val_loss를 모아서 평균을 계산함
            all_val_losses = [output["val_loss"] for output in self.validation_step_outputs]
            avg_val_loss = torch.stack(all_val_losses).mean()
            # 이곳에서 self.log 호출 시 on_step=False, on_epoch=True를 명시적으로 설정함.
            self.log("epoch/val_loss", avg_val_loss, prog_bar=True, on_epoch=True, on_step=False)
            # 에폭 종료 후 저장된 결과 초기화
            self.validation_step_outputs = []

    def inst_on_validation_epoch_end(self):
        if len(self.validation_epoch_samples) > 0:
            self.logger.log_table(
                key='valid/samples',
                columns=["sample_path", "global_step", "RNA"],
                data=self.validation_epoch_samples)
            self.validation_epoch_samples.clear()

        val_epoch_metrics = pd.concat(self.validation_epoch_metrics)
        
        for metric_name, metric_val in val_epoch_metrics.mean().to_dict().items():
            self._log_scalar(
                f'valid/{metric_name}',
                metric_val,
                on_step=False,
                on_epoch=True,
                prog_bar=False,
                batch_size=len(val_epoch_metrics),
            )
        self.validation_epoch_metrics.clear()

    def _log_scalar(
            self,
            key,
            value,
            on_step=True,
            on_epoch=False,
            prog_bar=True,
            batch_size=None,
            sync_dist=False,
            rank_zero_only=True
        ):
        if sync_dist and rank_zero_only:
            raise ValueError('Unable to sync dist when rank_zero_only=True')
        self.log(
            key,
            value,
            on_step=on_step,
            on_epoch=on_epoch,
            prog_bar=prog_bar,
            batch_size=batch_size,
            sync_dist=sync_dist,
            rank_zero_only=rank_zero_only
        )

    def training_step(self, batch, stage):
        """
        Performs one iteration of SE(3) flow matching and returns total training loss
        using the core and auxiliary losses computed in `model_step`.
        """
        step_start_time = time.time()
        self.interpolant.set_device(batch['res_mask'].device)
        noisy_batch = self.interpolant.corrupt_batch(batch)

        if self._interpolant_cfg.self_condition and random.random() > 0.5:
            with torch.no_grad():
                model_sc = self.model(noisy_batch)
                noisy_batch['trans_sc'] = model_sc['pred_trans']
        
        batch_losses = self.model_step(noisy_batch)
        num_batch = batch_losses['bb_atom_loss'].shape[0]
        total_losses = {
            k: torch.mean(v) for k,v in batch_losses.items()
        }
        
        for k,v in total_losses.items():
            self._log_scalar(f"train/{k}", v, prog_bar=False, batch_size=num_batch)
        
        # Losses to track. Stratified across t.
        t = torch.squeeze(noisy_batch['t'])
        self._log_scalar(
            "train/t",
            np.mean(du.to_numpy(t)),
            prog_bar=False, batch_size=num_batch)
        for loss_name, loss_dict in batch_losses.items():
            stratified_losses = mu.t_stratified_loss(
                t, loss_dict, loss_name=loss_name)
            for k,v in stratified_losses.items():
                self._log_scalar(f"train/{k}", v, prog_bar=False, batch_size=num_batch)

        # Training throughput
        self._log_scalar("train/length", batch['res_mask'].shape[1], prog_bar=False, batch_size=num_batch)
        self._log_scalar("train/batch_size", num_batch, prog_bar=False)
        
        step_time = time.time() - step_start_time
        self._log_scalar("train/eps", num_batch / step_time)


        train_loss = (
            total_losses[self._exp_cfg.training.loss] +
            total_losses['total_loss']
        )
        self._log_scalar("train/loss", train_loss, batch_size=num_batch)

        return train_loss

    def configure_optimizers(self):
        optimizer_config = self._exp_cfg.optimizer
        return torch.optim.AdamW(
            params=self.model.parameters(),
            lr=optimizer_config.lr
        )

    def test_step(self, batch, batch_idx):
        if self.val_bb is None :
            return
        else :
            return self.validation_step(batch, batch_idx)

    def predict_step(self, batch):
        """
        Params:
            batch (dict) : dictionary of number of RNA samples and respective number of RNA nucleotides to model

        Remarks:
            Used for unconditional sampling from the Interpolant. 
            Saves the generated all-atom backbones as PDB files at the specified saving directory in the inference config file.
        """

        device = f'cuda:{torch.cuda.current_device()}'
        interpolant = Interpolant(self._infer_cfg.interpolant) 
        interpolant.set_device(device)

        sample_length = batch['num_res'].item()
        diffuse_mask = torch.ones(1, sample_length).long().unsqueeze(0)
        sample_id = batch['sample_id'].item()
        sample_dir = os.path.join(self._output_dir, f'length_{sample_length}')
        os.makedirs(sample_dir, exist_ok=True)

        atom37_traj, _, _ = interpolant.sample(1, sample_length, self.model)
        bb_traj = du.to_numpy(torch.concat(atom37_traj, dim=0)) # convert from torch to numpy for easier processing

        sample = bb_traj[-1] # store last state (at the final ODESolve timestep) as completed sample
        
        # store RNA backbone sample as PDB file at `saved_rna_path` specified above
        saved_rna_path = au.write_complex_to_pdbs(
                sample,
                os.path.join(sample_dir, f'sample_{sample_id}'),
                is_na_residue_mask=diffuse_mask.detach().cpu(),
            )
        
        saved_rna_traj_path = au.write_complex_to_pdbs(
                bb_traj,
                os.path.join(sample_dir, f'sample_{sample_id}'),
                is_na_residue_mask=diffuse_mask.detach().cpu(),
            )
        
    def calc_energy(self, pdb_name):
        """
            Params : 
                pdb_name : Calculate the free energy of given pdb set
            Output :
                index : 가장 에너지가 낮은 timestep의 index return
        """
        calculation_path = "path"
        idx = [i*4 + 1 for i in range(25)]
        idx.append(1000)
        energy = []
        for i in idx :
            data = subprocess.check_output(f"./calc_energy {pdb_name}_{i}", cwd = calculation_path, shell = True)
            energy.append(data)
        
        return idx[energy.index(min(energy))]