import numpy as np
import torch.nn as nn
import torch

class MotionAlignment(nn.Module):
    def __init__(self, input_dim, output_dim, num_heads, max_seq_len=301, max_time_len = 30):
        super().__init__()
        self.sequence_embedding = nn.Embedding(max_seq_len, input_dim//2)  # 최대 시퀀스 길이만큼 위치 임베딩
        self.timestep_embedding = nn.Embedding(max_time_len, input_dim//2)
        self.attention = nn.MultiheadAttention(embed_dim=input_dim, num_heads=num_heads, batch_first=True)
        self.linear = nn.Linear(input_dim, output_dim)

    def forward(self, V_ref, V_s):
        """
        V_s: Noised Node (B, S, D)  # 배치, 시퀀스 길이, 특성 차원
        V_mot: Motion Node (B, 1, D)
        V_ref: Reference Node (B, 1, D)
        """
        batch_size, node_seq_len, dim = V_s.shape

        timestep = 26
        B = batch_size // timestep

        # 노드 결합 (V_mot, V_ref는 1개 시퀀스지만, V_s는 S개 시퀀스를 가짐)
        # combined_nodes = torch.cat([V_mot, V_ref, V_s], dim=1)  # (B, 2+S, D)

        V_s_reshaped = V_s.view(B, timestep, node_seq_len, dim)
        V_s_with_ref = torch.cat([V_ref.unsqueeze(1), V_s_reshaped], dim=1)
        seq_len = timestep + 1  # 27
        V_s_with_ref = V_s_with_ref.view(B, seq_len, node_seq_len, dim)

        # 위치 임베딩 추가 (시퀀스 길이에 맞게 생성)
        timestep_indices = torch.arange(seq_len, dtype=torch.long, device=V_s.device)
        timestep_embedding = self.timestep_embedding(timestep_indices)
        sequence_indices = torch.arange(node_seq_len, dtype=torch.long, device=V_s.device)
        sequence_embedding = self.sequence_embedding(sequence_indices)

        position_embedding = torch.cat([
            timestep_embedding.unsqueeze(1).expand(-1, node_seq_len, -1),  # (T, 1, D/2) → (T, S, D/2)
            sequence_embedding.unsqueeze(0).expand(seq_len, -1, -1)  # (1, S, D/2) → (T, S, D/2)
        ], dim=-1)  # 최종 (T, S, D)
        
        # Attention 적용 (Q=K=V로 사용)
        causal_mask = torch.triu(torch.ones(node_seq_len, node_seq_len, device=V_s.device), diagonal=1)
        causal_mask = causal_mask.masked_fill(causal_mask == 1, float('-inf'))

        attn_output = torch.zeros_like(V_s_with_ref)

        for i in range(B):
            attn_out, _ = self.attention(
                V_s_with_ref[i] + position_embedding,  # (27, 67, 256)
                V_s_with_ref[i] + position_embedding,  # (27, 67, 256)
                V_s_with_ref[i] + position_embedding,  # (27, 67, 256)
                attn_mask=causal_mask  # Causal Mask 적용
            )  # (27, 67, 256)
            attn_output[i] = attn_out  # 해당 batch의 결과 저장

        # 선형 변환
        output = self.linear(attn_output)

        final_output = output[:, 1:, :, :].reshape(timestep*B, node_seq_len, dim)

        return final_output  # (26*B, 67, output_dim)

class SpatialModule(nn.Module):
    def __init__(self, input_dim, num_heads):
        """
        Reference Network using Self-Attention.

        Args:
            input_dim (int): Feature dimension (D).
            num_heads (int): Number of heads for multi-head self-attention.
        """
        super().__init__()
        
        # Self-Attention Layer
        self.self_attention = nn.MultiheadAttention(embed_dim=input_dim, num_heads=num_heads, batch_first=True)
        
        # Projection Matrix Wr (2D × D)
        self.projection = nn.Linear(2 * input_dim, input_dim)

        # Linear Projection Wr (D × D)
        self.linear = nn.Linear(input_dim, input_dim)


    def forward(self, V_ref, V_s):
        """
        Forward pass of Reference Network.

        Args:
            V_ref (torch.Tensor): Reference node features (S × N × D).
            V_s (torch.Tensor): Noisy node features (S × N × D).

        Returns:
            torch.Tensor: Updated noisy node features (V̂_s^l).
        """
        # Step 1: Concatenate reference and noisy node features along the last dimension
        combined_features = torch.cat([V_ref, V_s], dim=-1)  # Shape: (S, N, 2D)

        # Step 2: Project to D-dimensional space for Self-Attention
        projected_features = self.projection(combined_features)  # Shape: (S, N, D)

        # Step 3: Apply Self-Attention
        attn_output, _ = self.self_attention(projected_features, projected_features, projected_features)

        # Step 4: Linear transformation
        A_s = self.linear(attn_output)  # Shape: (S, N, D)

        # Step 5: Residual connection with original noisy node features
        V_s_hat = A_s + V_s  # Shape: (S, N, D)

        return V_s_hat
    
class EdgeUpdate(nn.Module):
    def __init__(self, D_v, D_z):
        super(EdgeUpdate, self).__init__()
        self.linear = nn.Linear(D_v, D_v // 2)
        self.mlp = nn.Sequential(
            nn.LayerNorm(D_v // 2 + D_v // 2 + D_z),
            nn.Linear(D_v // 2 + D_v // 2 + D_z, D_v // 2 + D_v // 2 + D_z)
        )

    def forward(self, V, Z):
        V_down = self.linear(V)  # Linear(V^{l+1})
        Z_in = torch.cat((V_down.unsqueeze(1).expand(-1, V.size(1), -1), 
                          V_down.unsqueeze(0).expand(V.size(1), -1, -1), 
                          Z), dim=-1)  # concat(V_down, V_down, Z^{l+1})

        Z_out = self.mlp(Z_in)  # MLP(Z_in)
        return Z_out
    
def quat_to_rot_matrix(quat):
    """
    Convert a quaternion to a rotation matrix.
    """
    a, b, c, d = quat[:, 0], quat[:, 1], quat[:, 2], quat[:, 3]
    
    aa, bb, cc, dd = a*a, b*b, c*c, d*d
    ab, ac, ad, bc, bd, cd = a*b, a*c, a*d, b*c, b*d, c*d
    
    rot_matrix = torch.stack([
        1 - 2*(cc + dd), 2*(bc - ad), 2*(bd + ac),
        2*(bc + ad), 1 - 2*(bb + dd), 2*(cd - ab),
        2*(bd - ac), 2*(cd + ab), 1 - 2*(bb + cc)
    ], dim=-1).reshape(-1, 3, 3)
    
    return rot_matrix

class BackboneUpdate(nn.Module):
    def __init__(self, D_v):
        super(BackboneUpdate, self).__init__()
        self.linear = nn.Linear(D_v, 6)  # Output: (b_i, c_i, d_i, X_update_i)
    
    def forward(self, V):
        updates = self.linear(V)  # Linear(V_i^l)
        b, c, d, X_update = updates[:, :1], updates[:, 1:2], updates[:, 2:3], updates[:, 3:]
        
        # Normalize quaternion
        a = torch.ones_like(b)
        norm_factor = torch.sqrt(1 + b**2 + c**2 + d**2)
        a, b, c, d = a / norm_factor, b / norm_factor, c / norm_factor, d / norm_factor
        
        # Update rotation matrix
        R_update = quat_to_rot_matrix(torch.cat([a, b, c, d], dim=-1))
        
        return R_update, X_update


def Process_trajectory():
    return


import torch
import math

class SinusoidalTimeEmbedding(torch.nn.Module):
    def __init__(self, embedding_dim):
        super(SinusoidalTimeEmbedding, self).__init__()
        self.embedding_dim = embedding_dim
    
    def forward(self, time_tensor):
        """
        Args:
            time_tensor: Tensor of shape [seq_len, batch_size] or [batch_size, seq_len] containing time steps or time values
        """
        # Ensure time_tensor is [seq_len, batch_size]
        if time_tensor.dim() == 2 and time_tensor.size(0) != self.embedding_dim:
            time_tensor = time_tensor.transpose(0, 1)
        
        seq_len, batch_size = time_tensor.size()
        
        # Create a tensor to hold the time embeddings
        time_emb = torch.zeros(seq_len, batch_size, self.embedding_dim, device=time_tensor.device)
        
        # Compute the scaling factors for the sine and cosine functions
        div_term = torch.exp(torch.arange(0, self.embedding_dim, 2, device=time_tensor.device).float() * (-math.log(10000.0) / self.embedding_dim))
        
        # Apply sine to even indices
        time_emb[:, :, 0::2] = torch.sin(time_tensor.unsqueeze(-1) * div_term)
        
        # Apply cosine to odd indices
        time_emb[:, :, 1::2] = torch.cos(time_tensor.unsqueeze(-1) * div_term)
        
        return time_emb
    
class NodeTimeEmbedding(torch.nn.Module):
    def __init__(self, embedding_dim):
        super(NodeTimeEmbedding, self).__init__()
        self.embedding_dim = embedding_dim
    
    def forward(self, node_embed):
        """
        Args:
            node_embed: Tensor of shape [26*b, N, 256]
        """
        b = 1 #추후 config의 batch size에 맞게 바꾸기
        N = node_embed.shape[1]
        
        # 시간 텐서 생성
        time_steps = torch.arange(26, device=node_embed.device)
        time_tensor = time_steps.repeat_interleave(b)  # [26*b]
        
        # 스케일링 팩터 계산
        div_term = torch.exp(torch.arange(0, self.embedding_dim, 2, device=node_embed.device).float() * (-math.log(10000.0) / self.embedding_dim))
        
        # time embedding 계산 [26*b, 256]
        time_emb = torch.zeros(26*b, self.embedding_dim, device=node_embed.device)
        time_emb[:, 0::2] = torch.sin(time_tensor.unsqueeze(-1) * div_term)
        time_emb[:, 1::2] = torch.cos(time_tensor.unsqueeze(-1) * div_term)
        
        # 노드 차원으로 확장 [26*b, N, 256]
        time_emb = time_emb.unsqueeze(1).expand(-1, N, -1)

        return node_embed + time_emb

class EdgeTimeEmbedding(torch.nn.Module):
    def __init__(self, embedding_dim):
        super(EdgeTimeEmbedding, self).__init__()
        self.embedding_dim = embedding_dim
    
    def forward(self, edge_embed):
        """
        Args:
            edge_embed: Tensor of shape [26*b, N, N, 128]
        """
        b = 1
        N = edge_embed.shape[1]
        
        # 시간 텐서 생성
        time_steps = torch.arange(26, device=edge_embed.device)
        time_tensor = time_steps.repeat_interleave(b)  # [26*b]
        
        # 스케일링 팩터 계산
        div_term = torch.exp(torch.arange(0, self.embedding_dim, 2, device=edge_embed.device).float() * (-math.log(10000.0) / self.embedding_dim))
        
        # time embedding 계산 [26*b, 128]
        time_emb = torch.zeros(26*b, self.embedding_dim, device=edge_embed.device)
        time_emb[:, 0::2] = torch.sin(time_tensor.unsqueeze(-1) * div_term)
        time_emb[:, 1::2] = torch.cos(time_tensor.unsqueeze(-1) * div_term)
        
        # 노드 차원으로 확장 [26*b, N, N, 128]
        time_emb = time_emb.unsqueeze(1).unsqueeze(2).expand(-1, N, N, -1)
        
        return edge_embed + time_emb

class NodeFeatureUpdater(nn.Module):
    def __init__(self, aatype_dim=4, embed_dim=32, node_feat_dim=256):
        """
        aatype_dim: 가능한 aatype 값 개수 (4, 5, 6, 7 -> 총 4개)
        embed_dim: aatype을 임베딩할 차원
        node_feat_dim: 최종적으로 init_node_embed 차원과 맞추기 위한 차원
        """
        super().__init__()
        self.aatype_embedding = nn.Embedding(num_embeddings=8, embedding_dim=embed_dim)  # 8로 설정 (안전하게)
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, 128),
            nn.ReLU(),
            nn.Linear(128, node_feat_dim),
        )

    def forward(self, init_node_embed, aatype):
        """
        init_node_embed: (batch, N, 256)
        aatype: (batch, N) -> 염기서열 정보
        
        Returns:
        updated_node_feat: (batch, N, 256)
        """
        # aatype을 임베딩
        aatype_embed = self.aatype_embedding(torch.clamp(aatype, min=0, max=7))  # (batch, N, embed_dim)

        # FFN을 통과하여 (batch, N, 256)로 변환
        aatype_embed_transformed = self.ffn(aatype_embed)

        # 기존 node_embed와 합성 (concat 또는 sum 가능)
        updated_node_feat = init_node_embed + aatype_embed_transformed

        return updated_node_feat