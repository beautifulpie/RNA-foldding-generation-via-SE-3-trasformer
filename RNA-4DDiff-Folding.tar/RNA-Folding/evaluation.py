from Bio.PDB import PDBParser
import numpy as np
import os

csv_list_path = ""
result_dir = "/workspace/4D-Diff-RNA_test_1/debug_outputs/pdb_make/"
save_path = ""

def extract_alpha_carbons(pdb_file):
    """
    주어진 PDB 파일에서 'C4''  좌표를 추출합니다.
    단, 각 residue에 'C4'' 원자가 있어야 합니다.
    """
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("RNA", pdb_file)
    alpha_coords = []
    # 모델, 체인, 잔기 순으로 순회합니다.
    for model in structure:
        for chain in model:
            for residue in chain:
                # 만약 잔기에 알파 탄소가 있다면 좌표를 저장합니다.
                if 'C4\'' in residue:
                    alpha_coords.append(residue['C4\''].get_coord())
    return np.array(alpha_coords)

def compute_rmsd(coords1, coords2):
    """
    두 구조의 C4 좌표 배열이 주어졌을 때 RMSD를 계산합니다.
    두 배열의 크기가 다르면 ValueError를 발생시킵니다.
    """
    if coords1.shape != coords2.shape:
        raise ValueError("두 파일의 C4' 수가 다릅니다.")
    diff = coords1 - coords2
    return np.sqrt(np.sum(diff**2) / len(coords1))

if __name__ == "__main__":
    # if os.path.exist(csv_list_path):
        # rmsd_list = []
        # with open(csv_list_path, "r") as f:
        #     lines = f.readlines()
        #     for pdb_name in lines:
        #         pdb_name.strip("\n")
                
                if True :
                    for i in range(26):
                        pred_pdb = f"{result_dir}na_sample_{i}_first_pred.pdb"
                        gt_pdb = f"{result_dir}na_sample_{i}_first_gt.pdb"

                        coords1 = extract_alpha_carbons(pred_pdb)
                        coords2 = extract_alpha_carbons(gt_pdb)
                        
                        # 각 파일에서 알파 탄소 좌표를 추출합니다.
                        coords1 = extract_alpha_carbons(pred_pdb)
                        coords2 = extract_alpha_carbons(gt_pdb)

                        # 두 구조의 RMSD를 계산합니다.
                        rmsd_value = compute_rmsd(coords1, coords2)
                        print("알파 탄소 RMSD:", rmsd_value)

                else :
                    pred_pdb = f"{result_dir}{pdb_name}/na_sample_25_first_pred.pdb"
                    gt_pdb = f"{result_dir}{pdb_name}/na_sample_25_first_gt.pdb"
                coords1 = extract_alpha_carbons(pred_pdb)
                coords2 = extract_alpha_carbons(gt_pdb)
                
                # 각 파일에서 알파 탄소 좌표를 추출합니다.
                coords1 = extract_alpha_carbons(pred_pdb)
                coords2 = extract_alpha_carbons(gt_pdb)

                # 두 구조의 RMSD를 계산합니다.
                rmsd_value = compute_rmsd(coords1, coords2)
                # print("알파 탄소 RMSD:", rmsd_value)
                # rmsd_list.append(())
