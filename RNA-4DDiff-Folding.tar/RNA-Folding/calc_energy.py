import numpy as np
from Bio.PDB import PDBParser
import scipy.optimize
import scipy.linalg
import scipy.constants as const

def load_pdb(file):
    """Load a PDB file and return a Bio.PDB structure."""
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("RNA", file)
    return structure

def get_atom_list(structure):
    """Return a list of atoms from the structure."""
    atoms = list(structure.get_atoms())
    return atoms

def get_coordinates(atoms):
    """Extract coordinates from atom objects; returns an (N,3) array."""
    coords = np.array([atom.get_coord() for atom in atoms])
    return coords

def build_bonds(atoms, coords, bond_threshold=2.0):
    """
    Build a list of bonds based on a distance threshold.
    Each bond is represented as a tuple (i, j, r0) where r0 is the equilibrium distance.
    This is a very simplistic approach to infer connectivity.
    """
    N = len(atoms)
    bonds = []
    for i in range(N):
        for j in range(i+1, N):
            dist = np.linalg.norm(coords[i] - coords[j])
            if dist < bond_threshold:
                bonds.append((i, j, dist))
    return bonds

def potential_energy(x, bonds, num_atoms, k_bond=100.0):
    """
    Define a simple harmonic potential energy function.
    x: flattened coordinate array (3*num_atoms,)
    bonds: list of bonds with (i, j, r0)
    k_bond: bond force constant (arbitrary units)
    """
    coords = x.reshape((num_atoms, 3))
    U = 0.0
    for (i, j, r0) in bonds:
        r = np.linalg.norm(coords[i] - coords[j])
        U += 0.5 * k_bond * (r - r0)**2
    return U

def minimize_energy(x0, bonds, num_atoms, k_bond=100.0):
    """Minimize the potential energy using L-BFGS-B."""
    res = scipy.optimize.minimize(potential_energy, x0, args=(bonds, num_atoms, k_bond),
                                  method='L-BFGS-B')
    return res.x, res.fun

def compute_hessian(x, bonds, num_atoms, k_bond=100.0, epsilon=1e-4):
    """
    Compute the Hessian matrix numerically using central finite differences.
    x: flattened coordinate array at the minimized structure.
    Returns a 3N x 3N matrix.
    """
    n = x.size
    H = np.zeros((n, n))
    f0 = potential_energy(x, bonds, num_atoms, k_bond)
    # Loop over each coordinate i
    for i in range(n):
        x_eps = np.copy(x)
        x_eps[i] += epsilon
        f1 = potential_energy(x_eps, bonds, num_atoms, k_bond)
        for j in range(i, n):
            x_eps2 = np.copy(x)
            x_eps2[j] += epsilon
            f2 = potential_energy(x_eps2, bonds, num_atoms, k_bond)
            x_eps_ij = np.copy(x)
            x_eps_ij[i] += epsilon
            x_eps_ij[j] += epsilon
            f12 = potential_energy(x_eps_ij, bonds, num_atoms, k_bond)
            H[i, j] = (f12 - f1 - f2 + f0) / (epsilon**2)
            H[j, i] = H[i, j]
    return H

def get_atom_masses(atoms):
    """
    Retrieve atomic masses (in atomic mass units) from atom objects.
    Uses a simple dictionary for common elements.
    """
    mass_dict = {
        'H': 1.008,
        'C': 12.01,
        'N': 14.01,
        'O': 16.00,
        'P': 30.97,
        # Extend with other elements as needed
    }
    masses = []
    for atom in atoms:
        # Try to use atom.element if available; otherwise, guess from the name.
        element = atom.element.strip() if atom.element is not None else atom.get_name()[0]
        mass = mass_dict.get(element, 12.0)  # default mass if unknown
        masses.append(mass)
    return np.array(masses)

def mass_weight_hessian(H, masses):
    """
    Mass-weight the Hessian matrix.
    H: Hessian matrix (3N x 3N)
    masses: array of atomic masses (length N)
    For each coordinate i, the mass is masses[i//3].
    """
    n = H.shape[0]
    H_mass = np.zeros_like(H)
    for i in range(n):
        mi = masses[i // 3]
        for j in range(n):
            mj = masses[j // 3]
            H_mass[i, j] = H[i, j] / np.sqrt(mi * mj)
    return H_mass

def compute_frequencies(H_mass):
    """
    Diagonalize the mass-weighted Hessian to obtain eigenvalues.
    Positive eigenvalues correspond to squared angular frequencies.
    Returns an array of frequencies (in arbitrary units).
    """
    eigenvals, _ = np.linalg.eigh(H_mass)
    frequencies = []
    for eig in eigenvals:
        if eig > 0:
            freq = np.sqrt(eig)
            frequencies.append(freq)
    return np.array(frequencies)

def compute_vibrational_free_energy(frequencies, T=300.0):
    """
    Compute the vibrational free energy using the harmonic oscillator approximation:
    
    F_vib = 0.5 * sum(hbar*omega) + k_B*T * sum(ln(1 - exp(-hbar*omega/(k_B*T))))
    
    Note: In our example, the frequencies (omega) come out in arbitrary units.
    """
    hbar = const.hbar      # J*s
    kB = const.Boltzmann   # J/K
    F_vib = 0.0
    for omega in frequencies:
        term1 = 0.5 * hbar * omega
        # Avoid log(0) issues by checking the exponential
        exp_term = np.exp(-hbar * omega / (kB * T))
        if exp_term < 1.0:
            term2 = kB * T * np.log(1 - exp_term)
        else:
            term2 = 0.0
        F_vib += term1 + term2
    return F_vib

def main(pdb_file):
    # Load structure and extract atoms and coordinates.
    structure = load_pdb(pdb_file)
    atoms = get_atom_list(structure)
    coords = get_coordinates(atoms)
    num_atoms = len(atoms)
    x0 = coords.flatten()

    # Build a list of bonds using a distance cutoff.
    bonds = build_bonds(atoms, coords, bond_threshold=2.0)
    print("Number of atoms:", num_atoms)
    print("Number of bonds detected:", len(bonds))
    
    # Energy minimization
    x_min, U_min = minimize_energy(x0, bonds, num_atoms)
    print("Minimized potential energy (arbitrary units):", U_min)
    
    # Compute the Hessian at the minimized structure.
    H = compute_hessian(x_min, bonds, num_atoms)
    print("Hessian matrix computed.")
    
    # Mass-weight the Hessian.
    masses = get_atom_masses(atoms)
    H_mass = mass_weight_hessian(H, masses)
    
    # Diagonalize the mass-weighted Hessian to get vibrational frequencies.
    frequencies = compute_frequencies(H_mass)
    print("Frequencies (arbitrary units):", frequencies)
    
    # Compute vibrational free energy (units are illustrative).
    F_vib = compute_vibrational_free_energy(frequencies, T=300.0)
    print("Vibrational free energy (SI units, arbitrary scale):", F_vib)
    
    # Total free energy approximation (note: units are not fully consistent)
    F_total = U_min + F_vib
    print("Total free energy (approx., arbitrary units):", F_total)


# 메인 실행부
if __name__ == "__main__":
    # if len(sys.argv) < 2:
    #     print("Usage: python simrna_energy.py <pdb_file>")
    #     sys.exit(1)
    # pdb_file = sys.argv[1]
    # energy = compute_total_energy(pdb_file)
    # print(f"Total Energy: {energy:.3f}")
    path = "/workspace/4D-Diff-RNA_test_1/Single_RNA/Training_data/"
    for i in range(250):
        number = 1000001 + i *4
        i_index = str(number)
        index = i_index[1:]
        pdb_path = f"{path}fold_1A4D_1_A-B_1-{index}_AA.pdb"
        try :
            energy = main(pdb_path)
            print(f"{index} {energy:.3f}")
        except :
            print(f"{index}")
    index = "001000"
    pdb_path = f"{path}fold_1A4D_1_A-B_1-{index}_AA.pdb"
    energy = main(pdb_path)
    print(f"{index} {energy:.3f}")