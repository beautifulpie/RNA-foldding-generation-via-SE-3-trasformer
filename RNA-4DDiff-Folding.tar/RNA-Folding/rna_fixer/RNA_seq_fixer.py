def modify_pdb(pdb_path, sequence, output_path):
    """
    pdb_path: 입력 PDB 파일 경로
    sequence: 예, "ACGT..." (각 residue에 해당하는 nucleotide)
    output_path: 수정된 PDB를 저장할 파일 경로
    """
    # nucleotide 문자에 따른 residue name 매핑
    res_name_map = {
        'A': 'A',
        'C': 'C',
        'G': 'G',
        'T': 'T',
        'U': 'U'
    }
    
    # 백본 원자: 인산염과 리보스에 해당하는 원자들은 수정하지 않음.
    backbone_atoms = {"P", "OP1", "OP2", "O5'", "C5'", "C4'", "O4'", "C3'", "O3'", "C2'", "O2'", "C1'"}
    
    # pdb 파일 읽기
    with open(pdb_path, 'r') as f:
        lines = f.readlines()
    
    new_lines = []
    current_res_id = None
    res_index = 0  # sequence 인덱스
    
    # pdb 파일의 residue는 chain ID(22번째 문자)와 residue 번호(23-26번째 문자)로 구분
    for line in lines:
        if line.startswith("ATOM") or line.startswith("HETATM"):
            chain_id = line[21]          # 22번째 문자
            res_seq = line[22:26]          # 23-26번째 문자 (문자열)
            res_id = (chain_id, res_seq)
            
            # 새로운 residue이면 sequence에서 해당 nucleotide 가져오기
            if res_id != current_res_id:
                current_res_id = res_id
                if res_index < len(sequence):
                    nucleotide = sequence[res_index]
                else:
                    nucleotide = 'A'
                res_index += 1
                target_res_name = res_name_map.get(nucleotide)
            
            # residue name은 컬럼 18-20 (index 17:20)에 위치하므로 수정 (3자리, 오른쪽 정렬)
            new_line = line[:17] + target_res_name.rjust(3) + line[20:]
            
            # 원자 이름은 컬럼 13-16 (index 12:16)에 위치
            atom_name = new_line[12:16].strip()
            # 백본 원자가 아니면, 염기에 붙은 질소이므로 수정 대상
            if atom_name not in backbone_atoms:
                # purine (A, G)는 N9, pyrimidine (C, T)는 N1 사용
                if nucleotide in ['C', 'T']:
                    new_atom_name = "N1"
                else:
                    new_atom_name = "N9"
                # 4자리 필드로 맞추기 (오른쪽 정렬)
                new_atom_field = new_atom_name.rjust(4)
                new_line = new_line[:12] + new_atom_field + new_line[16:]
            
            new_lines.append(new_line)
        else:
            new_lines.append(line)
    
    # 수정된 pdb 내용을 output 파일에 저장
    with open(output_path, 'w') as f:
        f.writelines(new_lines)

# 예시 실행:
if __name__ == "__main__":
    pdb_file = "/workspace/4D-Diff-RNA_test_1/rna_fixer/test.pdb"      # 수정할 pdb 파일 경로
    seq = "ACUUCGGCUAGCCUUAAGC"            # 예시 sequence 정보
    output_file = "/workspace/4D-Diff-RNA_test_1/rna_fixer/test_output.pdb"
    modify_pdb(pdb_file, seq, output_file)
    print("수정된 PDB 파일이 저장되었습니다:", output_file)
