#!/usr/bin/env python
import sys
import numpy as np

# ----------------------------
# 1. 기본 유틸리티 함수
# ----------------------------
def normalize(v):
    return v / np.linalg.norm(v)

# ----------------------------
# 2. 당 프레임(sugar frame) 계산 함수
# ----------------------------
def compute_input_sugar_frame(residue_atoms):
    """
    입력 잔기의 당 프레임을 계산합니다.
    사용: C1', O4' 그리고 C2'
      - origin: C1'
      - x축: (O4' - C1') 방향
      - 임시: (C2' - C1')
      - z축: x축과 임시 벡터의 외적 (단, 정규화)
      - y축: z축과 x축의 외적
    반환: (origin, 3x3 rotation matrix [x, y, z] as columns)
    """
    origin = residue_atoms["C1'"]
    x_in = normalize(residue_atoms["O4'"] - origin)
    temp = normalize(residue_atoms["C2'"] - origin)
    z_in = normalize(np.cross(x_in, temp))
    y_in = np.cross(z_in, x_in)
    return origin, np.column_stack((x_in, y_in, z_in))

def compute_template_sugar_frame(template):
    """
    템플릿의 당 프레임을 계산합니다.
    템플릿에서는 C1'와 O4'는 있으나 C2'는 없으므로,
    보편적으로 canonical한 y축(예, [0,1,0])을 사용한 후,
    O4'로부터 orthogonal하게 보정합니다.
    반환: (origin, 3x3 rotation matrix)
    """
    origin = template["C1'"]
    x_temp = normalize(template["O4'"] - origin)
    canonical_y = np.array([0.0, 1.0, 0.0])
    # 만약 canonical_y와 x_temp가 거의 평행하면 다른 벡터 사용
    if np.allclose(np.abs(np.dot(canonical_y, x_temp)), 1.0, atol=1e-3):
        canonical_y = np.array([0.0, 0.0, 1.0])
    y_temp = canonical_y - np.dot(canonical_y, x_temp) * x_temp
    y_temp = normalize(y_temp)
    z_temp = np.cross(x_temp, y_temp)
    return origin, np.column_stack((x_temp, y_temp, z_temp))

# ----------------------------
# 3. 뉴클레오타이드 템플릿 데이터 (A, U, C, G)
# ----------------------------
# 여기서는 당과 베이스 원자 좌표가 포함되어 있다고 가정합니다.
# (백본의 C1'와 O4'는 당 프레임 계산에 사용되고, 그 외의 원자들은 베이스 영역입니다.)
nucleotide_templates = {
    'A': {
         "C1'": np.array([24.690, -1.827, 9.493]),
         "O4'": np.array([25.693, -1.570, 8.524]),
         # 베이스 원자들 (A의 경우 N9, C8, N7, C5, C6, N6, N1, C2, N3, C4)
         "N9":  np.array([24.640, -0.699, 10.422]),
         "C8":  np.array([25.060, 0.591, 10.210]),
         "N7":  np.array([24.848, 1.390, 11.228]),
         "C5":  np.array([24.249, 0.570, 12.176]),
         "C6":  np.array([23.777, 0.814, 13.479]),
         "N6":  np.array([23.824, 2.007, 14.076]),
         "N1":  np.array([23.234, -0.224, 14.154]),
         "C2":  np.array([23.175, -1.419, 13.553]),
         "N3":  np.array([23.582, -1.770, 12.337]),
         "C4":  np.array([24.116, -0.718, 11.692]),
         "base_ref": "N9"  # 참고용 필드
    },
    'U': {
         "C1'": np.array([12.287, 1.828, -5.163]),
         "O4'": np.array([11.829, 0.544, -4.748]),
         "N1":  np.array([11.433, 2.884, -4.555]),
         "C2":  np.array([11.418, 4.125, -5.161]),
         "O2":  np.array([12.068, 4.379, -6.161]),
         "N3":  np.array([10.619, 5.060, -4.553]),
         "C4":  np.array([9.846, 4.883, -3.425]),
         "O4":  np.array([9.176, 5.824, -2.995]),
         "C5":  np.array([9.915, 3.572, -2.857]),
         "C6":  np.array([10.685, 2.635, -3.424]),
         "base_ref": "N1"
    },
    'C': {
         "C1'": np.array([7.374, -0.460, -3.553]),
         "O4'": np.array([6.619, -1.266, -2.649]),
         "N1":  np.array([6.992, 0.973, -3.388]),
         "C2":  np.array([7.293, 1.874, -4.412]),
         "O2":  np.array([7.853, 1.455, -5.434]),
         "N3":  np.array([6.962, 3.177, -4.262]),
         "C4":  np.array([6.355, 3.589, -3.146]),
         "N4":  np.array([6.049, 4.884, -3.043]),
         "C5":  np.array([6.035, 2.691, -2.086]),
         "C6":  np.array([6.369, 1.402, -2.249]),
         "base_ref": "N1"
    },
    'G': {
         "C1'": np.array([15.967, 5.845, -4.886]),
         "O4'": np.array([16.030, 4.452, -5.160]),
         "N9":  np.array([14.898, 6.090, -3.918]),
         "C8":  np.array([14.351, 5.191, -3.036]),
         "N7":  np.array([13.431, 5.714, -2.273]),
         "C5":  np.array([13.367, 7.041, -2.677]),
         "C6":  np.array([12.552, 8.106, -2.212]),
         "O6":  np.array([11.702, 8.085, -1.315]),
         "N1":  np.array([12.806, 9.294, -2.896]),
         "C2":  np.array([13.734, 9.427, -3.903]),
         "N2":  np.array([13.839, 10.648, -4.448]),
         "N3":  np.array([14.499, 8.444, -4.344]),
         "C4":  np.array([14.265, 7.288, -3.692]),
         "base_ref": "N9"
    }
}

def precompute_template_relative_coords(template):
    """
    기존 코드와 달리 여기서는 템플릿 당 프레임을 따로 계산하여,
    각 베이스 원자에 대해 (template_base - C1')를 템플릿 당 프레임으로 표현한 값을 구합니다.
    """
    origin_temp, R_temp = compute_template_sugar_frame(template)
    rel_coords = {}
    for atom, coord in template.items():
        if atom in ["C1'", "O4'", "base_ref"]:
            continue
        rel_coords[atom] = R_temp.T @ (coord - origin_temp)
    return rel_coords

# 미리 템플릿의 베이스 상대 좌표를 계산해 둡니다.
for nt in nucleotide_templates:
    nucleotide_templates[nt]["base_relatives"] = precompute_template_relative_coords(nucleotide_templates[nt])

# ----------------------------
# 4. 잔기 업데이트 함수 (베이스 좌표 및 residue name 수정)
# ----------------------------
def update_residue_base(residue_atoms, target_nt):
    """
    입력 A‑only pdb 잔기의 백본(당, 인산 등)은 그대로 두고,
    target_nt 템플릿에 기반하여 베이스 원자 좌표를 업데이트합니다.
    여기서는 입력 잔기의 당 프레임(계산: C1', C2', O4')와
    템플릿의 당 프레임(계산: C1', O4' 및 canonical C2' 추정)을 사용하여
    베이스 상대 좌표 변환을 수행합니다.
    """
    # 입력 잔기 당 프레임 계산
    origin_in, R_in = compute_input_sugar_frame(residue_atoms)
    
    # 템플릿의 당 프레임 계산
    template = nucleotide_templates[target_nt]
    origin_temp, R_temp = compute_template_sugar_frame(template)
    
    # 템플릿 베이스 원자들의 상대 좌표 (템플릿 당 프레임 기준)
    base_relatives = template["base_relatives"]
    
    # 각 베이스 원자에 대해, 새 좌표 = 입력 당 origin + (입력 당 프레임 R_in) * (템플릿 상대 좌표)
    for atom, rel in base_relatives.items():
        residue_atoms[atom] = origin_in + R_in @ rel
    return residue_atoms

# ----------------------------
# 5. PDB 파일 파서 (입력 A‑only pdb 형식)
# ----------------------------
def parse_pdb(filename):
    """
    입력 PDB 파일을 읽어 잔기별로 그룹화합니다.
    각 잔기는 원자 이름과 좌표를 담은 딕셔너리와 해당 ATOM 라인 인덱스 리스트를 포함합니다.
    """
    with open(filename, 'r') as f:
        lines = f.readlines()
    residues = {}
    for i, line in enumerate(lines):
        if not line.startswith("ATOM"):
            continue
        # PDB 고정폭 필드: residue name (cols 18-20), chain (col22), resseq (cols 23-26)
        chain = line[21].strip() if len(line) >= 22 else ''
        resseq = line[22:26].strip()
        res_id = (chain, resseq)
        if res_id not in residues:
            residues[res_id] = {"atoms": {}, "atom_line_indices": []}
        atom_name = line[12:16].strip()
        try:
            x = float(line[30:38])
            y = float(line[38:46])
            z = float(line[46:54])
        except ValueError:
            continue
        residues[res_id]["atoms"][atom_name] = np.array([x, y, z])
        residues[res_id]["atom_line_indices"].append(i)
    
    # 순서대로 정렬
    residue_list = []
    for res_id, data in residues.items():
        first_idx = min(data["atom_line_indices"])
        residue_list.append((first_idx, res_id, data))
    residue_list.sort(key=lambda x: x[0])
    residues_ordered = []
    for _, res_id, data in residue_list:
        entry = {"res_id": res_id, "atoms": data["atoms"], "atom_line_indices": data["atom_line_indices"]}
        residues_ordered.append(entry)
    return lines, residues_ordered

# ----------------------------
# 6. main 함수: 명령행 인자 처리 및 전체 업데이트 루틴
# ----------------------------
def main():
    if len(sys.argv) != 4:
        print("Usage: python rna_fixer.py input.pdb sequence output.pdb")
        sys.exit(1)
    
    input_file = sys.argv[1]
    target_sequence = sys.argv[2].strip()  # 예: "AUGC..."
    output_file = sys.argv[3]
    
    lines, residues = parse_pdb(input_file)
    
    if len(residues) != len(target_sequence):
        print("Error: 잔기 수와 시퀀스 길이가 일치하지 않습니다.")
        sys.exit(1)
    
    # 각 잔기에 대해 베이스 좌표와 residue name을 업데이트
    for res, nt in zip(residues, target_sequence):
        update_residue_base(res["atoms"], nt)
        # residue name (cols 18-20)을 target nt로 변경 (3문자 폭, 오른쪽 정렬)
        new_resname = nt.rjust(3)
        for idx in res["atom_line_indices"]:
            line = lines[idx]
            new_line = line[:17] + new_resname + line[20:]
            lines[idx] = new_line

    # 각 잔기의 ATOM 라인에서 좌표 (cols 31-54) 업데이트
    for res in residues:
        for atom, new_coord in res["atoms"].items():
            for idx in res["atom_line_indices"]:
                line = lines[idx]
                if line[12:16].strip() == atom:
                    new_coords_str = f"{new_coord[0]:8.3f}{new_coord[1]:8.3f}{new_coord[2]:8.3f}"
                    new_line = line[:30] + new_coords_str + line[54:]
                    lines[idx] = new_line
                    break

    with open(output_file, 'w') as f:
        f.writelines(lines)
    print(f"업데이트 완료: {output_file}")

if __name__ == "__main__":
    main()
