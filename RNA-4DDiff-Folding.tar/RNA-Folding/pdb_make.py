import torch
import numpy as np
import os
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from data import all_atom as rna_all_atom
from Model.analysis import utils as au

# .pt 파일 불러오기
first_pred_bb = torch.load("debug_outputs/first_pred_epoch0.pt")
first_gt_bb = torch.load("debug_outputs/first_gt_epoch0.pt")
last_pred_bb = torch.load("debug_outputs/last_pred_epoch0.pt")
last_gt_bb = torch.load("debug_outputs/last_gt_epoch0.pt")
first_gt_tors = torch.load("debug_outputs/first_gt_tors_epoch0.pt")
first_pred_tors = torch.load("debug_outputs/first_pred_tors_epoch0.pt")
last_gt_tors = torch.load("debug_outputs/last_gt_tors_epoch0.pt")
last_pred_tors = torch.load("debug_outputs/last_pred_tors_epoch0.pt")
first_aatype = torch.load("debug_outputs/last_aatype_epoch0.pt")
last_aatype = torch.load("debug_outputs/last_aatype_epoch0.pt")
first_pred_rotmats = torch.load("debug_outputs/first_pred_rotmats_epoch0.pt")
first_gt_rotmats = torch.load("debug_outputs/first_gt_rotmats_epoch0.pt")
last_pred_rotmats = torch.load("debug_outputs/last_pred_rotmats_epoch0.pt")
last_gt_rotmats = torch.load("debug_outputs/last_gt_rotmats_epoch0.pt")
first_pred_trans = torch.load("debug_outputs/first_pred_trans_epoch0.pt")
first_gt_trans = torch.load("debug_outputs/first_gt_trans_epoch0.pt")
last_pred_trans = torch.load("debug_outputs/last_pred_trans_epoch0.pt")
last_gt_trans = torch.load("debug_outputs/last_gt_trans_epoch0.pt")

# 저장 디렉토리 생성
output_dir = "debug_outputs/pdb_make"
os.makedirs(output_dir, exist_ok=True)

# 🔹 is_na_residue_mask 생성 (기존 42에서 300으로 확장)
num_batch, orig_res = 26, 42
target_res = 300

first_is_na_residue_mask = torch.ones(num_batch, orig_res, device=first_pred_bb.device).bool()
last_is_na_residue_mask = torch.ones(num_batch, orig_res, device=first_pred_bb.device).bool()

# 패딩할 0(False) 텐서 생성 (300 - 42 크기의 0 행렬)
padding_tensor = torch.zeros(num_batch, target_res - orig_res, device=first_pred_bb.device).bool()

# 기존 텐서 + 패딩
first_is_na_residue_mask = torch.cat([first_is_na_residue_mask, padding_tensor], dim=1)
last_is_na_residue_mask = first_is_na_residue_mask

# 🔹 `trans` 및 `rotmats` 크기 맞추기 (300 → 42로 slice)
first_gt_trans = first_gt_trans[:, :orig_res, :]
first_gt_rotmats = first_gt_rotmats[:, :orig_res, :, :]
first_pred_trans = first_pred_trans[:, :orig_res, :]
first_pred_rotmats = first_pred_rotmats[:, :orig_res, :, :]

last_gt_trans = last_gt_trans[:, :orig_res, :]
last_gt_rotmats = last_gt_rotmats[:, :orig_res, :, :]
last_pred_trans = last_pred_trans[:, :orig_res, :]
last_pred_rotmats = last_pred_rotmats[:, :orig_res, :, :]

# 🔹 Torsion 데이터 크기 맞추기 (300 → 42로 slice)
first_gt_tors = first_gt_tors[:, :orig_res, :]
first_pred_tors = first_pred_tors[:, :orig_res, :]
last_gt_tors = last_gt_tors[:, :orig_res, :]
last_pred_tors = last_pred_tors[:, :orig_res, :]

# 🔹 Trajectory 리스트 생성
first_gt_traj = [(first_gt_trans, first_gt_rotmats)]
first_pred_traj = [(first_pred_trans, first_pred_rotmats)]
last_gt_traj = [(last_gt_trans, last_gt_rotmats)]
last_pred_traj = [(last_pred_trans, last_pred_rotmats)]

# 🔹 transrot_to_atom37_rna 실행
f_gt_rna = rna_all_atom.transrot_to_atom37_rna(first_gt_traj, first_is_na_residue_mask[:, :orig_res], first_gt_tors)
f_pred_rna = rna_all_atom.transrot_to_atom37_rna(first_pred_traj, first_is_na_residue_mask[:, :orig_res], first_pred_tors)
l_gt_rna = rna_all_atom.transrot_to_atom37_rna(last_gt_traj, last_is_na_residue_mask[:, :orig_res], last_gt_tors)
l_pred_rna = rna_all_atom.transrot_to_atom37_rna(last_pred_traj, last_is_na_residue_mask[:, :orig_res], last_pred_tors)

# 🔹 PDB 파일 저장
for i in range(26):
    final_pos = f_gt_rna[0][i]
    saved_rna_path = au.write_complex_to_pdbs(  # Save RNA atoms to PDB
        final_pos.cpu().numpy(),  # CPU로 이동하여 NumPy 배열로 변환
        os.path.join(output_dir, f'sample_{i}_first_gt.pdb'),
        is_na_residue_mask=first_is_na_residue_mask.cpu().numpy()[i],  # CPU로 이동하여 NumPy 변환
        no_indexing=True
    )

for i in range(26):
    final_pos = f_pred_rna[0][i]
    saved_rna_path = au.write_complex_to_pdbs(  # Save RNA atoms to PDB
        final_pos.cpu().numpy(),  # CPU로 이동하여 NumPy 배열로 변환
        os.path.join(output_dir, f'sample_{i}_first_pred.pdb'),
        is_na_residue_mask=first_is_na_residue_mask.cpu().numpy()[i],  # CPU로 이동하여 NumPy 변환
        no_indexing=True
    )

for i in range(26):
    final_pos = l_gt_rna[0][i]
    saved_rna_path = au.write_complex_to_pdbs(  # Save RNA atoms to PDB
        final_pos.cpu().numpy(),  # CPU로 이동하여 NumPy 배열로 변환
        os.path.join(output_dir, f'sample_{i}_last_gt.pdb'),
        is_na_residue_mask=first_is_na_residue_mask.cpu().numpy()[i],  # CPU로 이동하여 NumPy 변환
        no_indexing=True
    )

for i in range(26):
    final_pos = l_pred_rna[0][i]
    saved_rna_path = au.write_complex_to_pdbs(  # Save RNA atoms to PDB
        final_pos.cpu().numpy(),  # CPU로 이동하여 NumPy 배열로 변환
        os.path.join(output_dir, f'sample_{i}_last_pred.pdb'),
        is_na_residue_mask=first_is_na_residue_mask.cpu().numpy()[i],  # CPU로 이동하여 NumPy 변환
        no_indexing=True
    )